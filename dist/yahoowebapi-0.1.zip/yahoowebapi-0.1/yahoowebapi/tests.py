from yahoowebapi.shopping_web_service  import YahooShoppingAPI

api = YahooShoppingAPI('dj0zaiZpPUxFcWJTSWh6UUt6aCZzPWNvbnN1bWVyc2VjcmV0Jng9ZWE-')
# data = api.product_search(category_id=635, sort='-sold')
data = api.category_acquisition()
import pdb; pdb.set_trace()
